wheelHorizontal(document.querySelector(".horizontal"), {
  wheelSpeed: 1.2,
  smooth: true,
  smoothness: 0.12,
  header: "header",
  footer: "footer",
  headerGap: 30,
  footerGap: 12,
});
